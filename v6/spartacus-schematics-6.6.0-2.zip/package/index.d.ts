export { Schema as SpartacusOptions } from './src/add-spartacus/schema';
export * from './src/shared/index';
