"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.setupSpartacusModule = void 0;
var schematics_1 = require("@angular-devkit/schematics");
var constants_1 = require("../shared/constants");
var libs_constants_1 = require("../shared/libs-constants");
var new_module_utils_1 = require("../shared/utils/new-module-utils");
var program_1 = require("../shared/utils/program");
var project_tsconfig_paths_1 = require("../shared/utils/project-tsconfig-paths");
/** Migration which ensures the spartacus is being correctly set up */
function setupSpartacusModule(options) {
    return function (tree, context) {
        if (options.debug) {
            context.logger.info("\u231B\uFE0F Setting up Spartacus module...");
        }
        var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
        if (!buildPaths.length) {
            throw new schematics_1.SchematicsException('Could not find any tsconfig file. Cannot configure SpartacusModule.');
        }
        var basePath = process.cwd();
        for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
            var tsconfigPath = buildPaths_1[_i];
            configureSpartacusModules(tree, tsconfigPath, basePath);
        }
        if (options.debug) {
            context.logger.info("\u2705 Spartacus module setup complete.");
        }
        return tree;
    };
}
exports.setupSpartacusModule = setupSpartacusModule;
function configureSpartacusModules(tree, tsconfigPath, basePath) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    for (var _i = 0, appSourceFiles_1 = appSourceFiles; _i < appSourceFiles_1.length; _i++) {
        var sourceFile = appSourceFiles_1[_i];
        if (!sourceFile.getFilePath().includes("".concat(libs_constants_1.SPARTACUS_MODULE, ".module.ts"))) {
            continue;
        }
        (0, new_module_utils_1.addModuleImport)(sourceFile, {
            import: {
                moduleSpecifier: libs_constants_1.SPARTACUS_STOREFRONTLIB,
                namedImports: [constants_1.BASE_STOREFRONT_MODULE],
            },
            content: constants_1.BASE_STOREFRONT_MODULE,
            order: 0,
        });
        (0, new_module_utils_1.addModuleExport)(sourceFile, {
            import: {
                moduleSpecifier: libs_constants_1.SPARTACUS_STOREFRONTLIB,
                namedImports: [constants_1.BASE_STOREFRONT_MODULE],
            },
            content: constants_1.BASE_STOREFRONT_MODULE,
        });
        (0, program_1.saveAndFormat)(sourceFile);
        break;
    }
}
//# sourceMappingURL=spartacus.js.map