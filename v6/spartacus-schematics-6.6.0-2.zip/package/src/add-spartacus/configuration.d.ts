import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from './schema';
export declare function addSpartacusConfiguration(options: SpartacusOptions): Rule;
