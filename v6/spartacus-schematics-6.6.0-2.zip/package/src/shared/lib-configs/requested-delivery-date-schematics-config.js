"use strict";
/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.REQUESTED_DELIVERY_DATE_SCHEMATICS_CONFIG = exports.REQUESTED_DELIVERY_DATE_SCSS_FILE_NAME = exports.REQUESTED_DELIVERY_DATE_MODULE = exports.REQUESTED_DELIVERY_DATE_ROOT_MODULE = exports.REQUESTED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG = exports.REQUESTED_DELIVERY_DATE_TRANSLATIONS = exports.REQUESTED_DELIVERY_DATE_FOLDER_NAME = exports.REQUESTED_DELIVERY_DATE_FEATURE_NAME_CONSTANT = void 0;
var libs_constants_1 = require("../libs-constants");
exports.REQUESTED_DELIVERY_DATE_FEATURE_NAME_CONSTANT = 'REQUESTED_DELIVERY_DATE_FEATURE';
exports.REQUESTED_DELIVERY_DATE_FOLDER_NAME = 'requested-delivery-date';
exports.REQUESTED_DELIVERY_DATE_TRANSLATIONS = 'requestedDeliveryDateTranslations';
exports.REQUESTED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG = 'requestedDeliveryDateTranslationChunksConfig';
exports.REQUESTED_DELIVERY_DATE_ROOT_MODULE = 'RequestedDeliveryDateRootModule';
exports.REQUESTED_DELIVERY_DATE_MODULE = 'RequestedDeliveryDateModule';
exports.REQUESTED_DELIVERY_DATE_SCSS_FILE_NAME = 'requested-delivery-date.scss';
exports.REQUESTED_DELIVERY_DATE_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.REQUESTED_DELIVERY_DATE_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE,
    },
    folderName: exports.REQUESTED_DELIVERY_DATE_FOLDER_NAME,
    moduleName: exports.REQUESTED_DELIVERY_DATE_MODULE,
    featureModule: {
        name: exports.REQUESTED_DELIVERY_DATE_MODULE,
        importPath: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE,
    },
    rootModule: {
        name: exports.REQUESTED_DELIVERY_DATE_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE_ROOT,
    },
    styles: {
        scssFileName: exports.REQUESTED_DELIVERY_DATE_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE_ROOT,
        namedImports: [exports.REQUESTED_DELIVERY_DATE_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.REQUESTED_DELIVERY_DATE_TRANSLATIONS,
        chunks: exports.REQUESTED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE_ASSETS,
    },
    dependencyFeatures: [
        libs_constants_1.CART_BASE_FEATURE_NAME,
        libs_constants_1.CHECKOUT_BASE_FEATURE_NAME,
        libs_constants_1.ORDER_FEATURE_NAME,
    ],
};
//# sourceMappingURL=requested-delivery-date-schematics-config.js.map