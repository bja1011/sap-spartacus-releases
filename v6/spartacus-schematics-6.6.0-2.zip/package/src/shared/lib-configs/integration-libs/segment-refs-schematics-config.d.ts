import { SchematicConfig } from '../../utils/lib-utils';
export declare const SEGMENT_REFS_FOLDER_NAME = "segment-refs";
export declare const SEGMENT_REFS_MODULE_NAME = "SegmentRefs";
export declare const SEGMENT_REFS_ROOT_MODULE = "SegmentRefsRootModule";
export declare const SEGMENT_REF_FEATURE_NAME_CONSTANT = "SEGMENT_REFS_FEATURE";
export declare const SEGMENT_REFS_SCHEMATICS_CONFIG: SchematicConfig;
