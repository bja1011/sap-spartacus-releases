"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.SEGMENT_REFS_SCHEMATICS_CONFIG = exports.SEGMENT_REF_FEATURE_NAME_CONSTANT = exports.SEGMENT_REFS_ROOT_MODULE = exports.SEGMENT_REFS_MODULE_NAME = exports.SEGMENT_REFS_FOLDER_NAME = void 0;
var libs_constants_1 = require("../../libs-constants");
exports.SEGMENT_REFS_FOLDER_NAME = 'segment-refs';
exports.SEGMENT_REFS_MODULE_NAME = 'SegmentRefs';
exports.SEGMENT_REFS_ROOT_MODULE = 'SegmentRefsRootModule';
exports.SEGMENT_REF_FEATURE_NAME_CONSTANT = 'SEGMENT_REFS_FEATURE';
exports.SEGMENT_REFS_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.SEGMENT_REFS_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_SEGMENT_REFS,
    },
    folderName: exports.SEGMENT_REFS_FOLDER_NAME,
    moduleName: exports.SEGMENT_REFS_MODULE_NAME,
    featureModule: {
        name: exports.SEGMENT_REFS_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_SEGMENT_REFS,
    },
    rootModule: {
        importPath: libs_constants_1.SPARTACUS_SEGMENT_REFS_ROOT,
        name: exports.SEGMENT_REFS_ROOT_MODULE,
        content: "".concat(exports.SEGMENT_REFS_ROOT_MODULE),
    },
    /* Through Spartacus Segment-refs code doesnot have a dependency on Personalization,
    backend occ api of Segment-refs requires Personalization to be enabled , hence adding this dependency
    If Personalization library is not installed, Personalization & Segment-refs won't apply */
    dependencyFeatures: [libs_constants_1.TRACKING_PERSONALIZATION_FEATURE_NAME],
};
//# sourceMappingURL=segment-refs-schematics-config.js.map