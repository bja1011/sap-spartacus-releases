"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CDS_SCHEMATICS_CONFIG = exports.CDS_MODULE = exports.CDS_MODULE_NAME = exports.CDS_FOLDER_NAME = void 0;
var constants_1 = require("../../constants");
var libs_constants_1 = require("../../libs-constants");
exports.CDS_FOLDER_NAME = 'cds';
exports.CDS_MODULE_NAME = 'Cds';
exports.CDS_MODULE = 'CdsModule';
exports.CDS_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.CDS_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_CDS,
    },
    folderName: exports.CDS_FOLDER_NAME,
    moduleName: exports.CDS_MODULE_NAME,
    featureModule: {
        importPath: libs_constants_1.SPARTACUS_CDS,
        name: exports.CDS_MODULE,
        content: "".concat(exports.CDS_MODULE, ".forRoot()"),
    },
    customConfig: buildCdsConfig,
    dependencyFeatures: [libs_constants_1.TRACKING_PERSONALIZATION_FEATURE_NAME],
};
function buildCdsConfig(options) {
    var customConfig = [
        {
            import: [
                {
                    moduleSpecifier: libs_constants_1.SPARTACUS_CDS,
                    namedImports: [constants_1.CDS_CONFIG],
                },
            ],
            content: "<".concat(constants_1.CDS_CONFIG, ">{\n      cds: {\n        tenant: '").concat(options.tenant || 'TENANT_PLACEHOLDER', "',\n        baseUrl: '").concat(options.baseUrl || 'BASE_URL_PLACEHOLDER', "',\n        endpoints: {\n          strategyProducts: '/strategy/${tenant}/strategies/${strategyId}/products',\n        },\n        merchandising: {\n          defaultCarouselViewportThreshold: 80,\n        },\n      },\n    }"),
        },
    ];
    customConfig.push({
        import: [
            {
                moduleSpecifier: libs_constants_1.SPARTACUS_CDS,
                namedImports: [constants_1.CDS_CONFIG],
            },
        ],
        content: "<".concat(constants_1.CDS_CONFIG, ">{\n          cds: {\n            profileTag: {\n              javascriptUrl:\n                '").concat(options.profileTagLoadUrl ||
            'PROFILE_TAG_LOAD_URL_PLACEHOLDER', "',\n              configUrl:\n                '").concat(options.profileTagConfigUrl ||
            'PROFILE_TAG_CONFIG_URL_PLACEHOLDER', "',\n              allowInsecureCookies: true,\n            },\n          },\n        }"),
    });
    return {
        providers: customConfig,
        options: __assign(__assign({}, options), { lazy: false }),
    };
}
//# sourceMappingURL=cds-schematics-config.js.map