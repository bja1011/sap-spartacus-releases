import { SchematicConfig } from '../utils/lib-utils';
export declare const PDF_INVOICES_FEATURE_NAME_CONSTANT = "PDF_INVOICES_FEATURE";
export declare const PDF_INVOICES_FOLDER_NAME = "pdf-invoices";
export declare const PDF_INVOICES_TRANSLATIONS = "pdfInvoicesTranslations";
export declare const PDF_INVOICES_TRANSLATION_CHUNKS_CONFIG = "pdfInvoicesTranslationChunksConfig";
export declare const PDF_INVOICES_ROOT_MODULE = "PDFInvoicesRootModule";
export declare const PDF_INVOICES_MODULE = "PDFInvoicesModule";
export declare const PDF_INVOICES_SCSS_FILE_NAME = "pdf-invoices.scss";
export declare const PDF_INVOICES_SCHEMATICS_CONFIG: SchematicConfig;
