import { SchematicConfig } from '../utils/lib-utils';
export declare const REQUESTED_DELIVERY_DATE_FEATURE_NAME_CONSTANT = "REQUESTED_DELIVERY_DATE_FEATURE";
export declare const REQUESTED_DELIVERY_DATE_FOLDER_NAME = "requested-delivery-date";
export declare const REQUESTED_DELIVERY_DATE_TRANSLATIONS = "requestedDeliveryDateTranslations";
export declare const REQUESTED_DELIVERY_DATE_TRANSLATION_CHUNKS_CONFIG = "requestedDeliveryDateTranslationChunksConfig";
export declare const REQUESTED_DELIVERY_DATE_ROOT_MODULE = "RequestedDeliveryDateRootModule";
export declare const REQUESTED_DELIVERY_DATE_MODULE = "RequestedDeliveryDateModule";
export declare const REQUESTED_DELIVERY_DATE_SCSS_FILE_NAME = "requested-delivery-date.scss";
export declare const REQUESTED_DELIVERY_DATE_SCHEMATICS_CONFIG: SchematicConfig;
