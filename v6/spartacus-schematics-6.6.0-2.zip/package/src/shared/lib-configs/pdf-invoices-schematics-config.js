"use strict";
/*
 * SPDX-FileCopyrightText: 2022 SAP Spartacus team <spartacus-team@sap.com>
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.PDF_INVOICES_SCHEMATICS_CONFIG = exports.PDF_INVOICES_SCSS_FILE_NAME = exports.PDF_INVOICES_MODULE = exports.PDF_INVOICES_ROOT_MODULE = exports.PDF_INVOICES_TRANSLATION_CHUNKS_CONFIG = exports.PDF_INVOICES_TRANSLATIONS = exports.PDF_INVOICES_FOLDER_NAME = exports.PDF_INVOICES_FEATURE_NAME_CONSTANT = void 0;
var libs_constants_1 = require("../libs-constants");
exports.PDF_INVOICES_FEATURE_NAME_CONSTANT = 'PDF_INVOICES_FEATURE';
exports.PDF_INVOICES_FOLDER_NAME = 'pdf-invoices';
exports.PDF_INVOICES_TRANSLATIONS = 'pdfInvoicesTranslations';
exports.PDF_INVOICES_TRANSLATION_CHUNKS_CONFIG = 'pdfInvoicesTranslationChunksConfig';
exports.PDF_INVOICES_ROOT_MODULE = 'PDFInvoicesRootModule';
exports.PDF_INVOICES_MODULE = 'PDFInvoicesModule';
exports.PDF_INVOICES_SCSS_FILE_NAME = 'pdf-invoices.scss';
exports.PDF_INVOICES_SCHEMATICS_CONFIG = {
    library: {
        featureName: libs_constants_1.PDF_INVOICES_FEATURE_NAME,
        mainScope: libs_constants_1.SPARTACUS_REQUESTED_DELIVERY_DATE,
    },
    folderName: exports.PDF_INVOICES_FOLDER_NAME,
    moduleName: exports.PDF_INVOICES_MODULE,
    featureModule: {
        name: exports.PDF_INVOICES_MODULE,
        importPath: libs_constants_1.SPARTACUS_PDF_INVOICES,
    },
    rootModule: {
        name: exports.PDF_INVOICES_ROOT_MODULE,
        importPath: libs_constants_1.SPARTACUS_PDF_INVOICES_ROOT,
    },
    styles: {
        scssFileName: exports.PDF_INVOICES_SCSS_FILE_NAME,
        importStyle: libs_constants_1.SPARTACUS_PDF_INVOICES,
    },
    lazyLoadingChunk: {
        moduleSpecifier: libs_constants_1.SPARTACUS_PDF_INVOICES_ROOT,
        namedImports: [exports.PDF_INVOICES_FEATURE_NAME_CONSTANT],
    },
    i18n: {
        resources: exports.PDF_INVOICES_TRANSLATIONS,
        chunks: exports.PDF_INVOICES_TRANSLATION_CHUNKS_CONFIG,
        importPath: libs_constants_1.SPARTACUS_PDF_INVOICES_ASSETS,
    },
    dependencyFeatures: [libs_constants_1.USER_PROFILE_FEATURE_NAME],
};
//# sourceMappingURL=pdf-invoices-schematics-config.js.map