export declare function parseCSV(raw: string | undefined, defaultValues?: string[]): string;
