"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.saveAndFormat = exports.createProgram = void 0;
var ts_morph_1 = require("ts-morph");
var tree_file_system_1 = require("./tree-file-system");
function createProgram(tree, basePath, tsconfigPath) {
    var fs = new tree_file_system_1.TreeFileSystem(tree, basePath);
    var program = new ts_morph_1.Project({
        tsConfigFilePath: tsconfigPath,
        fileSystem: fs,
    });
    program.getTypeChecker();
    var appSourceFiles = program.getSourceFiles().filter(function (sourceFile) {
        return (!sourceFile.isDeclarationFile() &&
            !sourceFile.isFromExternalLibrary() &&
            !sourceFile.isInNodeModules());
    });
    return {
        program: program,
        appSourceFiles: appSourceFiles,
    };
}
exports.createProgram = createProgram;
function saveAndFormat(sourceFile) {
    sourceFile.organizeImports();
    sourceFile.formatText({
        ensureNewLineAtEndOfFile: true,
        indentSize: 2,
    });
    sourceFile.saveSync();
}
exports.saveAndFormat = saveAndFormat;
//# sourceMappingURL=program.js.map