"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __spreadArray = (this && this.__spreadArray) || function (to, from, pack) {
    if (pack || arguments.length === 2) for (var i = 0, l = from.length, ar; i < l; i++) {
        if (ar || !(i in from)) {
            if (!ar) ar = Array.prototype.slice.call(from, 0, i);
            ar[i] = from[i];
        }
    }
    return to.concat(ar || Array.prototype.slice.call(from));
};
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getServerTsPath = exports.getLineFromTSFile = exports.getMetadataProperty = exports.findMultiLevelNodesByTextAndKind = exports.renameIdentifierNode = exports.insertCommentAboveImportIdentifier = exports.insertCommentAboveIdentifier = exports.insertCommentAboveConfigProperty = exports.buildSpartacusComment = exports.injectService = exports.removeImport = exports.removeInjectImports = exports.shouldRemoveDecorator = exports.removeConstructorParam = exports.addConstructorParam = exports.isInheriting = exports.isCandidateForConstructorDeprecation = exports.defineProperty = exports.findConstructor = exports.commitChanges = exports.insertHtmlComment = exports.insertComponentSelectorComment = exports.getHtmlFiles = exports.getPathResultsForFile = exports.getIndexHtmlPath = exports.getAllTsSourceFiles = exports.getTsSourceFile = exports.InsertDirection = void 0;
var core_1 = require("@angular-devkit/core");
var schematics_1 = require("@angular-devkit/schematics");
var ast_utils_1 = require("@schematics/angular/utility/ast-utils");
var change_1 = require("@schematics/angular/utility/change");
var typescript_1 = __importDefault(require("typescript"));
var constants_1 = require("../constants");
var workspace_utils_1 = require("./workspace-utils");
var InsertDirection;
(function (InsertDirection) {
    InsertDirection[InsertDirection["LEFT"] = 0] = "LEFT";
    InsertDirection[InsertDirection["RIGHT"] = 1] = "RIGHT";
})(InsertDirection || (exports.InsertDirection = InsertDirection = {}));
function getTsSourceFile(tree, path) {
    var buffer = tree.read(path);
    if (!buffer) {
        throw new schematics_1.SchematicsException("Could not read file (".concat(path, ")."));
    }
    var content = buffer.toString(constants_1.UTF_8);
    var source = typescript_1.default.createSourceFile(path, content, typescript_1.default.ScriptTarget.Latest, true);
    return source;
}
exports.getTsSourceFile = getTsSourceFile;
function getAllTsSourceFiles(tree, basePath) {
    var results = [];
    tree.getDir(basePath).visit(function (filePath) {
        if (filePath.endsWith('.ts')) {
            results.push(filePath);
        }
    });
    return results.map(function (f) { return getTsSourceFile(tree, f); });
}
exports.getAllTsSourceFiles = getAllTsSourceFiles;
function getIndexHtmlPath(tree) {
    var _a, _b, _c, _d;
    var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(tree);
    var angularJson = (0, workspace_utils_1.getAngularJsonFile)(tree);
    var indexHtml = (_d = (_c = (_b = (_a = angularJson.projects[projectName]) === null || _a === void 0 ? void 0 : _a.architect) === null || _b === void 0 ? void 0 : _b.build) === null || _c === void 0 ? void 0 : _c.options) === null || _d === void 0 ? void 0 : _d.index;
    if (!indexHtml) {
        throw new schematics_1.SchematicsException('"index.html" file not found.');
    }
    return indexHtml;
}
exports.getIndexHtmlPath = getIndexHtmlPath;
function getPathResultsForFile(tree, file, directory) {
    var results = [];
    var dir = directory || '/';
    tree.getDir(dir).visit(function (filePath) {
        if (filePath.endsWith(file)) {
            results.push(filePath);
        }
    });
    return results;
}
exports.getPathResultsForFile = getPathResultsForFile;
function getHtmlFiles(tree, fileName, directory) {
    if (fileName === void 0) { fileName = '.html'; }
    return getPathResultsForFile(tree, fileName || '.html', directory);
}
exports.getHtmlFiles = getHtmlFiles;
function insertComponentSelectorComment(content, componentSelector, componentProperty) {
    var selector = buildSelector(componentSelector);
    var comment = buildHtmlComment(componentProperty.comment);
    var index = 0;
    var newContent = content;
    while (true) {
        index = getTextPosition(newContent, selector, index);
        if (index == null) {
            break;
        }
        newContent = newContent.slice(0, index) + comment + newContent.slice(index);
        index += comment.length + componentSelector.length;
    }
    return newContent;
}
exports.insertComponentSelectorComment = insertComponentSelectorComment;
function getTextPosition(content, text, startingPosition) {
    if (startingPosition === void 0) { startingPosition = 0; }
    var index = content.indexOf(text, startingPosition);
    return index !== -1 ? index : undefined;
}
function buildSelector(selector) {
    return "<".concat(selector);
}
function visitHtmlNodesRecursively(angularCompiler, nodes, propertyName, resultingElements, parentElement) {
    if (resultingElements === void 0) { resultingElements = []; }
    var Attribute = angularCompiler.Attribute, Element = angularCompiler.Element;
    nodes.forEach(function (node) {
        if (node instanceof Attribute && parentElement) {
            if (node.name.includes(propertyName) ||
                node.value.includes(propertyName)) {
                resultingElements.push(parentElement);
            }
        }
        if (node instanceof Element) {
            visitHtmlNodesRecursively(angularCompiler, node.attrs, propertyName, resultingElements, node);
            visitHtmlNodesRecursively(angularCompiler, node.children, propertyName, resultingElements, node);
        }
    });
}
function insertHtmlComment(content, componentProperty, angularCompiler) {
    var HtmlParser = angularCompiler.HtmlParser;
    var comment = buildHtmlComment(componentProperty.comment);
    var result = new HtmlParser().parse(content, '');
    var resultingElements = [];
    visitHtmlNodesRecursively(angularCompiler, result.rootNodes, componentProperty.name, resultingElements);
    resultingElements
        .map(function (node) { return node.sourceSpan.start.line; })
        .forEach(function (line, i) {
        var split = content.split('\n');
        split.splice(line + i, 0, comment);
        content = split.join('\n');
    });
    return content;
}
exports.insertHtmlComment = insertHtmlComment;
function buildHtmlComment(commentText) {
    return "<!-- ".concat(constants_1.TODO_SPARTACUS, " ").concat(commentText, " -->");
}
function commitChanges(host, path, changes, insertDirection) {
    if (insertDirection === void 0) { insertDirection = InsertDirection.RIGHT; }
    if (!changes || changes.length === 0) {
        return;
    }
    var recorder = host.beginUpdate(path);
    changes.forEach(function (change) {
        if (change instanceof change_1.InsertChange) {
            var pos = change.pos;
            var toAdd = change.toAdd;
            if (insertDirection === InsertDirection.LEFT) {
                recorder.insertLeft(pos, toAdd);
            }
            else {
                recorder.insertRight(pos, toAdd);
            }
        }
        else if (change instanceof change_1.RemoveChange) {
            var pos = change['pos'];
            var length_1 = change['toRemove'].length;
            recorder.remove(pos, length_1);
        }
        else if (change instanceof change_1.NoopChange) {
            // nothing to do here...
        }
        else {
            var pos = change['pos'];
            var oldText = change['oldText'];
            var newText = change['newText'];
            recorder.remove(pos, oldText.length);
            if (insertDirection === InsertDirection.LEFT) {
                recorder.insertLeft(pos, newText);
            }
            else {
                recorder.insertRight(pos, newText);
            }
        }
    });
    host.commitUpdate(recorder);
}
exports.commitChanges = commitChanges;
function findConstructor(nodes) {
    return nodes.find(function (n) { return n.kind === typescript_1.default.SyntaxKind.Constructor; });
}
exports.findConstructor = findConstructor;
function defineProperty(nodes, path, toAdd) {
    var constructorNode = findConstructor(nodes);
    if (!constructorNode) {
        throw new schematics_1.SchematicsException("No constructor found in ".concat(path, "."));
    }
    return new change_1.InsertChange(path, constructorNode.pos + 1, toAdd);
}
exports.defineProperty = defineProperty;
/**
 *
 * Method performs the following checks on the provided `source` file:
 * - is the file inheriting the provided `constructorDeprecation.class`
 * - is the `constructorDeprecation.class` imported from the specified `constructorDeprecation.importPath`
 * - is the file importing all the provided `parameterClassTypes` from the expected import path
 * - does the provided file contain a constructor
 * - does the `super()` call exist in the constructor
 * - does the param number passed to `super()` match the expected number
 * - does the order and the type of the constructor parameters match the expected `parameterClassTypes`
 *
 * If only once condition is not satisfied, the method returns `false`. Otherwise, it returns `true`.
 *
 * @param source a ts source file
 * @param inheritedClass a class which customers might have extended
 * @param parameterClassTypes a list of parameter class types. Must be provided in the order in which they appear in the deprecated constructor.
 */
function isCandidateForConstructorDeprecation(source, constructorDeprecation) {
    var nodes = (0, ast_utils_1.getSourceNodes)(source);
    if (!isInheriting(nodes, constructorDeprecation.class)) {
        return false;
    }
    if (!(0, ast_utils_1.isImported)(source, constructorDeprecation.class, constructorDeprecation.importPath)) {
        return false;
    }
    if (!checkImports(source, constructorDeprecation.deprecatedParams)) {
        return false;
    }
    var constructorNode = findConstructor(nodes);
    if (!constructorNode) {
        return false;
    }
    if (!checkConstructorParameters(constructorNode, constructorDeprecation.deprecatedParams)) {
        return false;
    }
    if (!checkSuper(constructorNode, constructorDeprecation.deprecatedParams)) {
        return false;
    }
    return true;
}
exports.isCandidateForConstructorDeprecation = isCandidateForConstructorDeprecation;
function isInheriting(nodes, inheritedClass) {
    var heritageClauseNodes = nodes.filter(function (node) { return node.kind === typescript_1.default.SyntaxKind.HeritageClause; });
    var heritageNodes = findMultiLevelNodesByTextAndKind(heritageClauseNodes, inheritedClass, typescript_1.default.SyntaxKind.Identifier);
    return heritageNodes.length !== 0;
}
exports.isInheriting = isInheriting;
function checkImports(source, parameterClassTypes) {
    for (var _i = 0, parameterClassTypes_1 = parameterClassTypes; _i < parameterClassTypes_1.length; _i++) {
        var classImport = parameterClassTypes_1[_i];
        if (classImport.importPath &&
            !(0, ast_utils_1.isImported)(source, classImport.className, classImport.importPath)) {
            return false;
        }
    }
    return true;
}
function checkConstructorParameters(constructorNode, parameterClassTypes) {
    var constructorParameters = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Parameter);
    var foundClassTypes = [];
    var _loop_1 = function (parameterClassType) {
        for (var _a = 0, constructorParameters_1 = constructorParameters; _a < constructorParameters_1.length; _a++) {
            var constructorParameter = constructorParameters_1[_a];
            var constructorParameterType = (0, ast_utils_1.findNodes)(constructorParameter, typescript_1.default.SyntaxKind.Identifier).filter(function (node) { return node.getText() === parameterClassType.className; });
            if (constructorParameterType.length !== 0) {
                foundClassTypes.push(parameterClassType);
                /*
                the break is needed to cope with multiple parameters of one type,
                e.g. constructor migrations for
               constructor(
                  protected cartStore: Store<StateWithMultiCart>,
                  protected store: Store<StateWithConfigurator>,
                  protected configuratorUtilsService: ConfiguratorUtilsService
                ) {}    */
                break;
            }
        }
    };
    for (var _i = 0, parameterClassTypes_2 = parameterClassTypes; _i < parameterClassTypes_2.length; _i++) {
        var parameterClassType = parameterClassTypes_2[_i];
        _loop_1(parameterClassType);
    }
    return foundClassTypes.length === parameterClassTypes.length;
}
function isInjected(constructorNode, parameterClassType) {
    var constructorParameters = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Parameter);
    for (var _i = 0, constructorParameters_2 = constructorParameters; _i < constructorParameters_2.length; _i++) {
        var constructorParameter = constructorParameters_2[_i];
        var constructorParameterType = (0, ast_utils_1.findNodes)(constructorParameter, typescript_1.default.SyntaxKind.Identifier).filter(function (node) { return node.getText() === parameterClassType.className; });
        if (constructorParameterType.length > 0) {
            return true;
        }
    }
    return false;
}
function checkSuper(constructorNode, parameterClassTypes) {
    var constructorBlock = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Block)[0];
    var callExpressions = (0, ast_utils_1.findNodes)(constructorBlock, typescript_1.default.SyntaxKind.CallExpression);
    if (callExpressions.length === 0) {
        return false;
    }
    // super has to be the first expression in constructor
    var firstCallExpression = callExpressions[0];
    var superKeyword = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.SuperKeyword);
    if (superKeyword && superKeyword.length === 0) {
        return false;
    }
    var params = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.Identifier);
    if (params.length !== parameterClassTypes.length) {
        return false;
    }
    return true;
}
function addConstructorParam(source, sourcePath, constructorNode, paramToAdd) {
    var _a, _b, _c;
    if (!constructorNode) {
        throw new schematics_1.SchematicsException("No constructor found in ".concat(sourcePath, "."));
    }
    var changes = [];
    if (!isInjected(constructorNode, paramToAdd)) {
        changes.push(injectService({
            constructorNode: constructorNode,
            path: sourcePath,
            serviceName: paramToAdd.className,
            modifier: 'no-modifier',
            propertyType: paramToAdd.literalInference,
            injectionToken: (_a = paramToAdd.injectionToken) === null || _a === void 0 ? void 0 : _a.token,
            isArray: (_b = paramToAdd.injectionToken) === null || _b === void 0 ? void 0 : _b.isArray,
        }));
    }
    if (paramToAdd.importPath &&
        !(0, ast_utils_1.isImported)(source, paramToAdd.className, paramToAdd.importPath)) {
        changes.push((0, ast_utils_1.insertImport)(source, sourcePath, paramToAdd.className, paramToAdd.importPath));
    }
    if ((_c = paramToAdd.injectionToken) === null || _c === void 0 ? void 0 : _c.token) {
        if (!(0, ast_utils_1.isImported)(source, constants_1.INJECT_DECORATOR, constants_1.ANGULAR_CORE)) {
            changes.push((0, ast_utils_1.insertImport)(source, sourcePath, constants_1.INJECT_DECORATOR, constants_1.ANGULAR_CORE));
        }
        /**
         * This is for the case when an injection token is the same as the import's type.
         * In this case we don't want to add two imports.
         * Ex: `@Inject(LaunchRenderStrategy) launchRenderStrategy: LaunchRenderStrategy[]`
         */
        if (paramToAdd.injectionToken.importPath &&
            paramToAdd.injectionToken.token !== paramToAdd.className &&
            !(0, ast_utils_1.isImported)(source, paramToAdd.injectionToken.token, paramToAdd.injectionToken.importPath)) {
            changes.push((0, ast_utils_1.insertImport)(source, sourcePath, paramToAdd.injectionToken.token, paramToAdd.injectionToken.importPath));
        }
    }
    var paramName = getParamName(source, constructorNode, paramToAdd);
    changes.push(updateConstructorSuperNode(sourcePath, constructorNode, paramName || paramToAdd.className));
    return changes;
}
exports.addConstructorParam = addConstructorParam;
function removeConstructorParam(source, sourcePath, constructorNode, paramToRemove) {
    if (!constructorNode) {
        throw new schematics_1.SchematicsException("No constructor found in ".concat(sourcePath, "."));
    }
    var changes = [];
    if (shouldRemoveImportAndParam(source, paramToRemove)) {
        var importRemovalChange = removeImport(source, paramToRemove);
        var injectImportRemovalChange = removeInjectImports(source, constructorNode, paramToRemove);
        var constructorParamRemovalChanges = removeConstructorParamInternal(sourcePath, constructorNode, paramToRemove);
        changes.push.apply(changes, __spreadArray(__spreadArray([importRemovalChange], constructorParamRemovalChanges, false), injectImportRemovalChange, false));
    }
    var paramName = getParamName(source, constructorNode, paramToRemove);
    if (!paramName) {
        return [new change_1.NoopChange()];
    }
    var superRemoval = removeParamFromSuper(sourcePath, constructorNode, paramName);
    changes.push.apply(changes, superRemoval);
    return changes;
}
exports.removeConstructorParam = removeConstructorParam;
function shouldRemoveDecorator(constructorNode, decoratorIdentifier) {
    var decoratorParameters = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Decorator).filter(function (x) { return x.getText().includes(decoratorIdentifier); });
    // if there are 0, or exactly 1 usage of the `decoratorIdentifier` in the whole class, we can safely remove it.
    return decoratorParameters.length < 2;
}
exports.shouldRemoveDecorator = shouldRemoveDecorator;
function getParamName(source, constructorNode, classType) {
    var nodes = (0, ast_utils_1.getSourceNodes)(source);
    var constructorParameters = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Parameter);
    var classDeclarationNode = nodes.find(function (node) { return node.kind === typescript_1.default.SyntaxKind.ClassDeclaration; });
    if (!classDeclarationNode) {
        return undefined;
    }
    for (var _i = 0, constructorParameters_3 = constructorParameters; _i < constructorParameters_3.length; _i++) {
        var constructorParameter = constructorParameters_3[_i];
        if (getClassName(constructorParameter) === classType.className) {
            var paramVariableNode = constructorParameter
                .getChildren()
                .find(function (node) { return node.kind === typescript_1.default.SyntaxKind.Identifier; });
            var paramName = paramVariableNode
                ? paramVariableNode.getText()
                : undefined;
            return paramName;
        }
    }
    return undefined;
}
function getClassName(constructorParameter) {
    var _a;
    var identifierNode = (_a = constructorParameter
        .getChildren()
        .find(function (node) { return node.kind === typescript_1.default.SyntaxKind.TypeReference; })) === null || _a === void 0 ? void 0 : _a.getChildren().find(function (node) { return node.kind === typescript_1.default.SyntaxKind.Identifier; });
    return identifierNode ? identifierNode.getText() : undefined;
}
function shouldRemoveImportAndParam(source, importToRemove) {
    var nodes = (0, ast_utils_1.getSourceNodes)(source);
    var constructorNode = findConstructor(nodes);
    if (!constructorNode) {
        return true;
    }
    var classDeclarationNode = nodes.find(function (node) { return node.kind === typescript_1.default.SyntaxKind.ClassDeclaration; });
    if (!classDeclarationNode) {
        return true;
    }
    var constructorParameters = getConstructorParameterList(constructorNode);
    var _loop_2 = function (constructorParameter) {
        if (constructorParameter.getText().includes(importToRemove.className)) {
            var paramVariableNode = constructorParameter
                .getChildren()
                .find(function (node) { return node.kind === typescript_1.default.SyntaxKind.Identifier; });
            var paramName_1 = paramVariableNode ? paramVariableNode.getText() : '';
            var paramUsages = (0, ast_utils_1.findNodes)(classDeclarationNode, typescript_1.default.SyntaxKind.Identifier).filter(function (node) { return node.getText() === paramName_1; });
            // if there are more than two usages (injection and passing to super), then the param is used elsewhere in the class
            if (paramUsages.length > 2) {
                return { value: false };
            }
            return { value: true };
        }
    };
    for (var _i = 0, constructorParameters_4 = constructorParameters; _i < constructorParameters_4.length; _i++) {
        var constructorParameter = constructorParameters_4[_i];
        var state_1 = _loop_2(constructorParameter);
        if (typeof state_1 === "object")
            return state_1.value;
    }
    return true;
}
function removeInjectImports(source, constructorNode, paramToRemove) {
    if (!paramToRemove.injectionToken) {
        return [new change_1.NoopChange()];
    }
    var importRemovalChange = [];
    if (shouldRemoveDecorator(constructorNode, constants_1.INJECT_DECORATOR)) {
        importRemovalChange.push(removeImport(source, {
            className: constants_1.INJECT_DECORATOR,
            importPath: constants_1.ANGULAR_CORE,
        }));
    }
    /**
     * This is for the case when an injection token is the same as the import's type.
     * In this case we don't want to have two import removal changes.
     * Ex: `@Inject(LaunchRenderStrategy) launchRenderStrategy: LaunchRenderStrategy[]`
     */
    if (paramToRemove.injectionToken.importPath &&
        paramToRemove.injectionToken.token !== paramToRemove.className) {
        importRemovalChange.push(removeImport(source, {
            className: paramToRemove.injectionToken.token,
            importPath: paramToRemove.injectionToken.importPath,
        }));
    }
    return importRemovalChange;
}
exports.removeInjectImports = removeInjectImports;
function removeImport(source, importToRemove) {
    var importDeclarationNode = getImportDeclarationNode(source, importToRemove);
    if (!importDeclarationNode) {
        return new change_1.NoopChange();
    }
    var position;
    var toRemove = importToRemove.className;
    var importSpecifierNodes = (0, ast_utils_1.findNodes)(importDeclarationNode, typescript_1.default.SyntaxKind.ImportSpecifier);
    if (importSpecifierNodes.length === 1) {
        // delete the whole import line
        position = importDeclarationNode.getStart();
        toRemove = importDeclarationNode.getText();
    }
    else {
        // delete only the specified import, and leave the rest
        var importSpecifier = importSpecifierNodes
            .map(function (node, i) {
            var importNode = (0, ast_utils_1.findNode)(node, typescript_1.default.SyntaxKind.Identifier, importToRemove.className);
            return {
                importNode: importNode,
                i: i,
            };
        })
            .filter(function (result) { return result.importNode; })[0];
        if (!importSpecifier.importNode) {
            return new change_1.NoopChange();
        }
        // in case the import that needs to be removed is in the middle, we need to remove the ',' that follows the found import
        if (importSpecifier.i !== importSpecifierNodes.length - 1) {
            toRemove += ',';
        }
        position = importSpecifier.importNode.getStart();
    }
    return new change_1.RemoveChange(source.fileName, position, toRemove);
}
exports.removeImport = removeImport;
function getImportDeclarationNode(source, importToCheck) {
    if (!importToCheck.importPath) {
        return undefined;
    }
    // collect al the import declarations
    var importDeclarationNodes = getImportDeclarations(source, importToCheck.importPath);
    if (importDeclarationNodes.length === 0) {
        return undefined;
    }
    // find the one that contains the specified `importToCheck.className`
    var importDeclarationNode = importDeclarationNodes[0];
    for (var _i = 0, importDeclarationNodes_1 = importDeclarationNodes; _i < importDeclarationNodes_1.length; _i++) {
        var currentImportDeclaration = importDeclarationNodes_1[_i];
        var importIdentifiers = (0, ast_utils_1.findNodes)(currentImportDeclaration, typescript_1.default.SyntaxKind.Identifier);
        var found = importIdentifiers.find(function (node) { return node.getText() === importToCheck.className; });
        if (found) {
            importDeclarationNode = currentImportDeclaration;
            break;
        }
    }
    return importDeclarationNode;
}
function getConstructorParameterList(constructorNode) {
    var syntaxList = constructorNode
        .getChildren()
        .filter(function (node) { return node.kind === typescript_1.default.SyntaxKind.SyntaxList; })[0];
    return (0, ast_utils_1.findNodes)(syntaxList, typescript_1.default.SyntaxKind.Parameter);
}
function removeConstructorParamInternal(sourcePath, constructorNode, importToRemove) {
    var constructorParameters = getConstructorParameterList(constructorNode);
    for (var i = 0; i < constructorParameters.length; i++) {
        var constructorParameter = constructorParameters[i];
        if (constructorParameter.getText().includes(importToRemove.className)) {
            var changes = [];
            // if it's not the first parameter that should be removed, we should remove the comma after the previous parameter
            if (i !== 0) {
                var previousParameter = constructorParameters[i - 1];
                changes.push(new change_1.RemoveChange(sourcePath, previousParameter.end, ','));
                // if removing the first param, cleanup the comma after it
            }
            else if (i === 0 && constructorParameters.length > 1) {
                var commas = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.CommaToken);
                // get the comma that matches the constructor parameter's position
                var comma = commas[i];
                changes.push(new change_1.RemoveChange(sourcePath, comma.getStart(), ','));
            }
            changes.push(new change_1.RemoveChange(sourcePath, constructorParameter.getStart(), constructorParameter.getText()));
            return changes;
        }
    }
    return [];
}
function removeParamFromSuper(sourcePath, constructorNode, paramName) {
    var constructorBlock = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Block)[0];
    var callExpressions = (0, ast_utils_1.findNodes)(constructorBlock, typescript_1.default.SyntaxKind.CallExpression);
    if (callExpressions.length === 0) {
        throw new schematics_1.SchematicsException('No super() call found.');
    }
    var changes = [];
    // `super()` has to be the first expression in constructor
    var firstCallExpression = callExpressions[0];
    var params = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.Identifier);
    var commas = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.CommaToken);
    for (var i = 0; i < params.length; i++) {
        var param = params[i];
        if (param.getText() === paramName) {
            if (i !== 0) {
                var previousCommaPosition = commas[i - 1].getStart();
                changes.push(new change_1.RemoveChange(sourcePath, previousCommaPosition, ','));
                // if removing the first param, cleanup the comma after it
            }
            else if (i === 0 && params.length > 0) {
                // get the comma that matches the constructor parameter's position
                var comma = commas[i];
                changes.push(new change_1.RemoveChange(sourcePath, comma.getStart(), ','));
            }
            changes.push(new change_1.RemoveChange(sourcePath, param.getStart(), paramName));
            break;
        }
    }
    return changes;
}
function updateConstructorSuperNode(sourcePath, constructorNode, propertyName) {
    var callBlock = (0, ast_utils_1.findNodes)(constructorNode, typescript_1.default.SyntaxKind.Block);
    propertyName = core_1.strings.camelize(propertyName);
    if (callBlock.length === 0) {
        throw new schematics_1.SchematicsException('No constructor body found.');
    }
    var callExpression = (0, ast_utils_1.findNodes)(callBlock[0], typescript_1.default.SyntaxKind.CallExpression);
    // super has to be the first expression in constructor
    var firstCallExpression = callExpression[0];
    var superKeyword = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.SuperKeyword);
    if (superKeyword && superKeyword.length === 0) {
        throw new schematics_1.SchematicsException('No super() call found.');
    }
    var toInsert = '';
    var position;
    var params = (0, ast_utils_1.findNodes)(firstCallExpression, typescript_1.default.SyntaxKind.Identifier);
    // just an empty super() call, without any params passed to it
    if (params.length === 0) {
        position = superKeyword[0].end + 1;
    }
    else {
        var lastParam = params[params.length - 1];
        toInsert += ', ';
        position = lastParam.end;
    }
    toInsert += propertyName;
    return new change_1.InsertChange(sourcePath, position, toInsert);
}
function injectService(config) {
    var _a;
    if (!config.constructorNode) {
        throw new schematics_1.SchematicsException("No constructor found in ".concat(config.path, "."));
    }
    var constructorParameters = getConstructorParameterList(config.constructorNode);
    var toInsert = '';
    var position = config.constructorNode.getStart() + 'constructor('.length;
    if (constructorParameters.length > 0) {
        toInsert += ', ';
        var lastParam = constructorParameters[constructorParameters.length - 1];
        position = lastParam.end;
    }
    config.propertyName = config.propertyName
        ? core_1.strings.camelize(config.propertyName)
        : core_1.strings.camelize(config.serviceName);
    config.propertyType =
        (_a = config.propertyType) !== null && _a !== void 0 ? _a : core_1.strings.classify(config.serviceName);
    if (config.injectionToken) {
        toInsert += "@Inject(".concat(config.injectionToken, ") ");
    }
    if (config.modifier !== 'no-modifier') {
        toInsert += "".concat(config.modifier, " ");
    }
    toInsert += "".concat(config.propertyName, ": ").concat(config.propertyType);
    if (config.isArray) {
        toInsert += '[]';
    }
    return new change_1.InsertChange(config.path, position, toInsert);
}
exports.injectService = injectService;
function buildSpartacusComment(comment) {
    return "// ".concat(constants_1.TODO_SPARTACUS, " ").concat(comment, "\n");
}
exports.buildSpartacusComment = buildSpartacusComment;
function insertCommentAboveConfigProperty(sourcePath, source, identifierName, comment) {
    var identifierNodes = new Set();
    (0, ast_utils_1.getSourceNodes)(source)
        .filter(function (node) { return node.kind === typescript_1.default.SyntaxKind.ObjectLiteralExpression; })
        .forEach(function (objectLiteralNode) {
        return (0, ast_utils_1.findNodes)(objectLiteralNode, typescript_1.default.SyntaxKind.Identifier)
            .filter(function (node) { return node.getText() === identifierName; })
            .forEach(function (idNode) { return identifierNodes.add(idNode); });
    });
    var changes = [];
    identifierNodes.forEach(function (n) {
        return changes.push(new change_1.InsertChange(sourcePath, getLineStartFromTSFile(source, n.getStart()), "".concat(comment)));
    });
    return changes;
}
exports.insertCommentAboveConfigProperty = insertCommentAboveConfigProperty;
function insertCommentAboveIdentifier(sourcePath, source, identifierName, comment, identifierType) {
    if (identifierType === void 0) { identifierType = typescript_1.default.SyntaxKind.Identifier; }
    var changes = [];
    (0, ast_utils_1.getSourceNodes)(source).forEach(function (node) {
        if (node.kind !== typescript_1.default.SyntaxKind.ClassDeclaration) {
            return;
        }
        var identifierNodes = (0, ast_utils_1.findNodes)(node, identifierType).filter(function (identifierNode) { return identifierNode.getText() === identifierName; });
        identifierNodes.forEach(function (n) {
            return changes.push(new change_1.InsertChange(sourcePath, getLineStartFromTSFile(source, n.getStart()), "".concat(comment)));
        });
    });
    return changes;
}
exports.insertCommentAboveIdentifier = insertCommentAboveIdentifier;
function getImportDeclarations(source, importPath) {
    var imports = (0, ast_utils_1.getSourceNodes)(source).filter(function (node) { return node.kind === typescript_1.default.SyntaxKind.ImportDeclaration; });
    return imports.filter(function (imp) {
        return imp.moduleSpecifier
            .getText()
            .includes(importPath);
    });
}
function filterNamespacedImports(imports) {
    return imports
        .filter(function (imp) { var _a, _b; return (_b = (_a = imp.importClause) === null || _a === void 0 ? void 0 : _a.namedBindings) === null || _b === void 0 ? void 0 : _b.name; })
        .filter(Boolean);
}
function filterNamedImports(imports) {
    return imports
        .filter(function (imp) { var _a, _b; return (_b = (_a = imp.importClause) === null || _a === void 0 ? void 0 : _a.namedBindings) === null || _b === void 0 ? void 0 : _b.elements; })
        .filter(Boolean);
}
function insertCommentAboveImportIdentifier(sourcePath, source, identifierName, importPath, comment) {
    var imports = getImportDeclarations(source, importPath);
    var namedImports = filterNamedImports(imports);
    var namespacedImports = filterNamespacedImports(imports);
    var namespacedIdentifiers = namespacedImports
        .map(function (imp) { var _a, _b, _c; return (_c = (_b = (_a = imp.importClause) === null || _a === void 0 ? void 0 : _a.namedBindings) === null || _b === void 0 ? void 0 : _b.name) === null || _c === void 0 ? void 0 : _c.escapedText; })
        .filter(Boolean);
    var namedImportsWithIdentifierName = namedImports.filter(function (imp) {
        return (0, ast_utils_1.findNodes)(imp, typescript_1.default.SyntaxKind.ImportSpecifier).find(function (node) { return node.name.escapedText === identifierName; });
    });
    var propertyAccessExpressions = (0, ast_utils_1.getSourceNodes)(source).filter(function (node) { return node.kind === typescript_1.default.SyntaxKind.PropertyAccessExpression; });
    var accessPropertiesToIdentifierName = propertyAccessExpressions
        .filter(function (member) { var _a; return namespacedIdentifiers.includes((_a = member === null || member === void 0 ? void 0 : member.expression) === null || _a === void 0 ? void 0 : _a.escapedText); })
        .filter(function (member) { var _a; return identifierName === ((_a = member === null || member === void 0 ? void 0 : member.name) === null || _a === void 0 ? void 0 : _a.escapedText); })
        .filter(Boolean);
    var changes = [];
    namedImportsWithIdentifierName.forEach(function (n) {
        return changes.push(new change_1.InsertChange(sourcePath, getLineStartFromTSFile(source, n.getStart()), comment));
    });
    accessPropertiesToIdentifierName.forEach(function (n) {
        return changes.push(new change_1.InsertChange(sourcePath, getLineStartFromTSFile(source, n.getStart()), comment));
    });
    return changes;
}
exports.insertCommentAboveImportIdentifier = insertCommentAboveImportIdentifier;
function renameIdentifierNode(sourcePath, source, oldName, newName) {
    var identifierNodes = findLevel1NodesInSourceByTextAndKind(source, oldName, typescript_1.default.SyntaxKind.Identifier);
    var changes = [];
    identifierNodes.forEach(function (n) {
        return changes.push(new change_1.ReplaceChange(sourcePath, n.getStart(), oldName, newName));
    });
    return changes;
}
exports.renameIdentifierNode = renameIdentifierNode;
function findLevel1NodesInSourceByTextAndKind(source, text, syntaxKind) {
    var nodes = (0, ast_utils_1.getSourceNodes)(source);
    return findLevel1NodesByTextAndKind(nodes, text, syntaxKind);
}
function findLevel1NodesByTextAndKind(nodes, text, syntaxKind) {
    return nodes
        .filter(function (n) { return n.kind === syntaxKind; })
        .filter(function (n) { return n.getText() === text; });
}
function findMultiLevelNodesByTextAndKind(nodes, text, syntaxKind) {
    var result = [];
    for (var _i = 0, nodes_1 = nodes; _i < nodes_1.length; _i++) {
        var node = nodes_1[_i];
        result.push.apply(result, (0, ast_utils_1.findNodes)(node, syntaxKind).filter(function (n) { return n.getText() === text; }));
    }
    return result;
}
exports.findMultiLevelNodesByTextAndKind = findMultiLevelNodesByTextAndKind;
function getLineStartFromTSFile(source, position) {
    var lac = source.getLineAndCharacterOfPosition(position);
    return source.getPositionOfLineAndCharacter(lac.line, 0);
}
// as this is copied from https://github.com/angular/angular-cli/blob/master/packages/schematics/angular/app-shell/index.ts#L211, no need to test Angular's code
function getMetadataProperty(metadata, propertyName) {
    var properties = metadata.properties;
    var property = properties.filter(function (prop) {
        if (!typescript_1.default.isPropertyAssignment(prop)) {
            return false;
        }
        var name = prop.name;
        switch (name.kind) {
            case typescript_1.default.SyntaxKind.Identifier:
                return name.getText() === propertyName;
            case typescript_1.default.SyntaxKind.StringLiteral:
                return name.text === propertyName;
        }
        return false;
    })[0];
    return property;
}
exports.getMetadataProperty = getMetadataProperty;
function getLineFromTSFile(host, path, position, linesToRemove) {
    if (linesToRemove === void 0) { linesToRemove = 1; }
    var tsFile = getTsSourceFile(host, path);
    var lac = tsFile.getLineAndCharacterOfPosition(position);
    var lineStart = tsFile.getPositionOfLineAndCharacter(lac.line, 0);
    var nextLineStart = tsFile.getPositionOfLineAndCharacter(lac.line + linesToRemove, 0);
    return [lineStart, nextLineStart - lineStart];
}
exports.getLineFromTSFile = getLineFromTSFile;
function getServerTsPath(host) {
    var _a, _b, _c;
    var projectName = (0, workspace_utils_1.getDefaultProjectNameFromWorkspace)(host);
    var angularJson = (0, workspace_utils_1.getAngularJsonFile)(host);
    return (_c = (_b = (_a = angularJson.projects[projectName].architect) === null || _a === void 0 ? void 0 : _a.server) === null || _b === void 0 ? void 0 : _b.options) === null || _c === void 0 ? void 0 : _c.main;
}
exports.getServerTsPath = getServerTsPath;
//# sourceMappingURL=file-utils.js.map