/**
 * Returns the configured dependencies for the given feature.
 */
export declare function getConfiguredDependencies(feature: string): string[];
