import { WorkspaceProject } from '@schematics/angular/utility/workspace-models';
export declare function getStylesConfigFilePath(sourceRoot: string): string;
export declare function getRelativeStyleConfigImportPath(project: WorkspaceProject, destFilePath: string): string;
