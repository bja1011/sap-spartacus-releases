"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.kahnsAlgorithm = exports.crossFeatureInstallationOrder = exports.crossFeatureDependencyGraph = exports.crossLibraryInstallationOrder = exports.crossLibraryDependencyGraph = exports.Graph = void 0;
var dependencies_json_1 = __importDefault(require("../../dependencies.json"));
var libs_constants_1 = require("../libs-constants");
var schematics_config_mappings_1 = require("../schematics-config-mappings");
var schematics_config_utils_1 = require("./schematics-config-utils");
var Graph = /** @class */ (function () {
    function Graph(vertices) {
        this.adjacentVertices = {};
        if (vertices) {
            this.addVertex.apply(this, vertices);
        }
    }
    Graph.prototype.addVertex = function () {
        var vertices = [];
        for (var _i = 0; _i < arguments.length; _i++) {
            vertices[_i] = arguments[_i];
        }
        for (var _a = 0, vertices_1 = vertices; _a < vertices_1.length; _a++) {
            var vertex = vertices_1[_a];
            if (!this.adjacentVertices[vertex]) {
                this.adjacentVertices[vertex] = [];
            }
        }
    };
    Graph.prototype.createEdge = function (v1, v2) {
        this.adjacentVertices[v1].push(v2);
    };
    Graph.prototype.getAdjacentVertices = function () {
        return this.adjacentVertices;
    };
    return Graph;
}());
exports.Graph = Graph;
exports.crossLibraryDependencyGraph = createLibraryDependencyGraph();
exports.crossLibraryInstallationOrder = kahnsAlgorithm(exports.crossLibraryDependencyGraph);
exports.crossFeatureDependencyGraph = createCrossFeaturesDependencyGraph();
exports.crossFeatureInstallationOrder = groupFeatures();
function groupFeatures() {
    var order = kahnsAlgorithm(exports.crossFeatureDependencyGraph);
    var auxOrder = [];
    for (var _i = 0, _a = Array.from(order.entries()); _i < _a.length; _i++) {
        var _b = _a[_i], index = _b[0], feature = _b[1];
        var library = (0, schematics_config_mappings_1.getKeyByMappingValueOrThrow)(schematics_config_mappings_1.libraryFeatureMapping, feature);
        var lastExistingIndex = getLastLibraryIndex(auxOrder, library);
        if (!lastExistingIndex) {
            auxOrder.push({ library: library, feature: feature });
            continue;
        }
        auxOrder.splice(lastExistingIndex + 1, 0, { library: library, feature: feature });
        order.splice(index);
    }
    return auxOrder.map(function (_a) {
        var feature = _a.feature;
        return feature;
    });
}
function getLastLibraryIndex(auxOrder, library) {
    var lastIndex;
    for (var _i = 0, _a = Array.from(auxOrder.entries()); _i < _a.length; _i++) {
        var _b = _a[_i], index = _b[0], aux = _b[1];
        if (aux.library === library) {
            lastIndex = index;
        }
    }
    return lastIndex;
}
/**
 * Creates the order in which the Spartacus libraries should be installed.
 * https://en.wikipedia.org/wiki/Topological_sorting#Kahn's_algorithm
 */
function kahnsAlgorithm(graph) {
    // Calculate the incoming degree for each vertex
    var vertices = Object.keys(graph.getAdjacentVertices());
    var inDegree = {};
    for (var _i = 0, vertices_2 = vertices; _i < vertices_2.length; _i++) {
        var vertex = vertices_2[_i];
        for (var _a = 0, _b = graph.getAdjacentVertices()[vertex]; _a < _b.length; _a++) {
            var neighbor = _b[_a];
            inDegree[neighbor] = inDegree[neighbor] + 1 || 1;
        }
    }
    /**
     * if there are no relations in the given graph,
     * just return the vertices, preserving the order
     */
    if (!Object.keys(inDegree).length) {
        return vertices;
    }
    // Create a queue which stores the vertex without dependencies
    var queue = vertices.filter(function (vertex) { return !inDegree[vertex]; });
    var topNums = {};
    var index = 0;
    while (queue.length) {
        var vertex = queue.shift();
        if (!vertex) {
            continue;
        }
        topNums[vertex] = index++;
        // adjust the incoming degree of its neighbors
        for (var _c = 0, _d = graph.getAdjacentVertices()[vertex]; _c < _d.length; _c++) {
            var neighbor = _d[_c];
            inDegree[neighbor]--;
            if (inDegree[neighbor] === 0) {
                queue.push(neighbor);
            }
        }
    }
    if (index !== vertices.length) {
        throw new Error("Circular dependency detected.");
    }
    return Object.keys(topNums).reverse();
}
exports.kahnsAlgorithm = kahnsAlgorithm;
function createLibraryDependencyGraph() {
    var skip = libs_constants_1.CORE_SPARTACUS_SCOPES.concat('storefrontapp-e2e-cypress', 'storefrontapp');
    var spartacusLibraries = Object.keys(dependencies_json_1.default).filter(function (dependency) { return !skip.includes(dependency); });
    var graph = new Graph(spartacusLibraries);
    for (var _i = 0, spartacusLibraries_1 = spartacusLibraries; _i < spartacusLibraries_1.length; _i++) {
        var spartacusLib = spartacusLibraries_1[_i];
        var libraryDependencies = dependencies_json_1.default[spartacusLib];
        var spartacusPeerDependencies = Object.keys(libraryDependencies).filter(function (dependency) { return dependency.startsWith(libs_constants_1.SPARTACUS_SCOPE); });
        for (var _a = 0, spartacusPeerDependencies_1 = spartacusPeerDependencies; _a < spartacusPeerDependencies_1.length; _a++) {
            var spartacusPackage = spartacusPeerDependencies_1[_a];
            if (skip.includes(spartacusPackage)) {
                continue;
            }
            graph.createEdge(spartacusLib, spartacusPackage);
        }
    }
    return graph;
}
function createCrossFeaturesDependencyGraph() {
    var _a;
    var graph = new Graph();
    for (var _i = 0, _b = Array.from(schematics_config_mappings_1.libraryFeatureMapping.keys()); _i < _b.length; _i++) {
        var spartacusLib = _b[_i];
        var features = (_a = schematics_config_mappings_1.libraryFeatureMapping.get(spartacusLib)) !== null && _a !== void 0 ? _a : [];
        for (var _c = 0, features_1 = features; _c < features_1.length; _c++) {
            var feature = features_1[_c];
            graph.addVertex(feature);
            var dependencies = (0, schematics_config_utils_1.getConfiguredDependencies)(feature);
            for (var _d = 0, dependencies_1 = dependencies; _d < dependencies_1.length; _d++) {
                var dependency = dependencies_1[_d];
                graph.createEdge(feature, dependency);
            }
        }
    }
    return graph;
}
//# sourceMappingURL=graph-utils.js.map