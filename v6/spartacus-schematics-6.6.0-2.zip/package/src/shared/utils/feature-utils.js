"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
var __assign = (this && this.__assign) || function () {
    __assign = Object.assign || function(t) {
        for (var s, i = 1, n = arguments.length; i < n; i++) {
            s = arguments[i];
            for (var p in s) if (Object.prototype.hasOwnProperty.call(s, p))
                t[p] = s[p];
        }
        return t;
    };
    return __assign.apply(this, arguments);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getDynamicallyImportedLocalSourceFile = exports.findFeatureModule = exports.analyzeApplication = exports.getModuleConfig = exports.getSpartacusFeaturesModule = exports.addFeatures = void 0;
var schematics_1 = require("@angular-devkit/schematics");
var ts_morph_1 = require("ts-morph");
var constants_1 = require("../constants");
var libs_constants_1 = require("../libs-constants");
var schematics_config_mappings_1 = require("../schematics-config-mappings");
var graph_utils_1 = require("./graph-utils");
var import_utils_1 = require("./import-utils");
var lib_utils_1 = require("./lib-utils");
var new_module_utils_1 = require("./new-module-utils");
var program_1 = require("./program");
var project_tsconfig_paths_1 = require("./project-tsconfig-paths");
/**
 * Configures feature modules for the given array of features.
 *
 * Optionally, an override can be provided for the default
 * schematics options and/or feature-schematics configuration.
 */
function addFeatures(options, features) {
    return function (_tree, context) {
        var _a, _b, _c, _d;
        if (options.debug) {
            var message = "\n******************************\n";
            message += "Cross feature graph:\n";
            message += graph_utils_1.crossFeatureInstallationOrder.join(', ');
            message += "\n******************************\n";
            context.logger.info(message);
        }
        /**
         * In an existing Spartacus application, we don't want to
         * force-install the dependent features.
         */
        var featuresToInstall = ((_a = options.internal) === null || _a === void 0 ? void 0 : _a.existingSpartacusApplication)
            ? (_b = options.features) !== null && _b !== void 0 ? _b : []
            : features;
        var rules = [];
        for (var _i = 0, featuresToInstall_1 = featuresToInstall; _i < featuresToInstall_1.length; _i++) {
            var feature = featuresToInstall_1[_i];
            var schematicsConfiguration = schematics_config_mappings_1.featureSchematicConfigMapping.get(feature);
            if (!schematicsConfiguration) {
                throw new schematics_1.SchematicsException("[Internal] No feature config found for ".concat(feature, ". ") +
                    "Please check if the schematics config is added to projects/schematics/src/shared/schematics-config-mappings.ts");
            }
            // TODO:#schematics - fix the interactivity for the CDS / ASM, etc.
            var libraryOptions = (_d = (_c = schematicsConfiguration.customConfig) === null || _c === void 0 ? void 0 : _c.call(schematicsConfiguration, options).options) !== null && _d !== void 0 ? _d : options;
            rules.push((0, lib_utils_1.addLibraryFeature)(libraryOptions, schematicsConfiguration));
            var wrappers = analyzeWrappers(schematicsConfiguration, libraryOptions);
            for (var _e = 0, wrappers_1 = wrappers; _e < wrappers_1.length; _e++) {
                var wrapperOptions = wrappers_1[_e].wrapperOptions;
                rules.push((0, schematics_1.externalSchematic)(libs_constants_1.SPARTACUS_SCHEMATICS, 'wrapper-module', wrapperOptions));
            }
        }
        return (0, schematics_1.chain)(rules);
    };
}
exports.addFeatures = addFeatures;
/**
 * Analyzes the given schematics configuration for the wrapper modules.
 * It builds the options for the wrapper schematic run,
 * including the execution sequence.
 */
function analyzeWrappers(schematicsConfiguration, options) {
    var _a;
    if (!((_a = schematicsConfiguration.importAfter) === null || _a === void 0 ? void 0 : _a.length)) {
        return [];
    }
    var result = [];
    for (var _i = 0, _b = schematicsConfiguration.importAfter; _i < _b.length; _i++) {
        var importAfterConfig = _b[_i];
        var wrapperOptions = {
            scope: options.scope,
            interactive: options.interactive,
            project: options.project,
            markerModuleName: importAfterConfig.markerModuleName,
            featureModuleName: importAfterConfig.featureModuleName,
            debug: options.debug,
        };
        var analysis = {
            markerModuleName: importAfterConfig.markerModuleName,
            wrapperOptions: wrapperOptions,
        };
        result.push(analysis);
    }
    return result;
}
/**
 * If exists, it returns the spartacus-features.module.ts' source.
 * Otherwise, it returns undefined.
 */
function getSpartacusFeaturesModule(tree, basePath, tsconfigPath) {
    var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
    for (var _i = 0, appSourceFiles_1 = appSourceFiles; _i < appSourceFiles_1.length; _i++) {
        var sourceFile = appSourceFiles_1[_i];
        if (sourceFile
            .getFilePath()
            .includes("".concat(libs_constants_1.SPARTACUS_FEATURES_MODULE, ".module.ts"))) {
            if (getSpartacusFeaturesNgModuleDecorator(sourceFile)) {
                return sourceFile;
            }
        }
    }
    return undefined;
}
exports.getSpartacusFeaturesModule = getSpartacusFeaturesModule;
/**
 * Returns the NgModule decorator, if exists.
 */
function getSpartacusFeaturesNgModuleDecorator(sourceFile) {
    var spartacusFeaturesModule;
    function visitor(node) {
        if (ts_morph_1.Node.isCallExpression(node)) {
            var expression = node.getExpression();
            if (ts_morph_1.Node.isIdentifier(expression) &&
                expression.getText() === 'NgModule' &&
                (0, import_utils_1.isImportedFrom)(expression, constants_1.ANGULAR_CORE)) {
                var classDeclaration = node.getFirstAncestorByKind(ts_morph_1.ts.SyntaxKind.ClassDeclaration);
                if (classDeclaration) {
                    var identifier = classDeclaration.getNameNode();
                    if (identifier &&
                        identifier.getText() === libs_constants_1.SPARTACUS_FEATURES_NG_MODULE) {
                        spartacusFeaturesModule = node;
                    }
                }
            }
        }
        node.forEachChild(visitor);
    }
    sourceFile.forEachChild(visitor);
    return spartacusFeaturesModule;
}
/**
 * For the given feature module name,
 * returns the module configuration part
 * of the given schematics feature config
 */
function getModuleConfig(featureModuleName, featureConfig) {
    var featureModuleConfigs = [].concat(featureConfig.featureModule);
    for (var _i = 0, featureModuleConfigs_1 = featureModuleConfigs; _i < featureModuleConfigs_1.length; _i++) {
        var featureModuleConfig = featureModuleConfigs_1[_i];
        if (featureModuleConfig.name === featureModuleName) {
            return featureModuleConfig;
        }
    }
    return undefined;
}
exports.getModuleConfig = getModuleConfig;
/**
 * Analyzes the customers' application.
 * It checks for presence of Spartacus features and
 * whether they're configured or present in package.json.
 */
function analyzeApplication(options, allFeatures) {
    return function (tree, context) {
        var _a, _b;
        var spartacusFeatureModuleExists = (0, lib_utils_1.checkAppStructure)(tree, options.project);
        /**
         * Mutates the options, and sets the internal properties
         * for later usage in other rules.
         */
        options.internal = __assign(__assign({}, options.internal), { existingSpartacusApplication: spartacusFeatureModuleExists });
        if (!options.internal.existingSpartacusApplication) {
            var dependentFeaturesMessage = createDependentFeaturesLog(options, allFeatures);
            if (dependentFeaturesMessage) {
                context.logger.info(dependentFeaturesMessage);
            }
            return (0, schematics_1.noop)();
        }
        logDebugInfo("\u231B\uFE0F Analyzing application...");
        for (var _i = 0, _c = (_a = options.features) !== null && _a !== void 0 ? _a : []; _i < _c.length; _i++) {
            var targetFeature = _c[_i];
            var targetFeatureConfig = (0, schematics_config_mappings_1.getSchematicsConfigByFeatureOrThrow)(targetFeature);
            if (!((_b = targetFeatureConfig.importAfter) === null || _b === void 0 ? void 0 : _b.length)) {
                continue;
            }
            var wrappers = analyzeWrappers(targetFeatureConfig, options);
            for (var _d = 0, wrappers_2 = wrappers; _d < wrappers_2.length; _d++) {
                var wrapperOptions = wrappers_2[_d].wrapperOptions;
                var markerFeature = (0, schematics_config_mappings_1.getKeyByMappingValueOrThrow)(schematics_config_mappings_1.featureFeatureModuleMapping, wrapperOptions.markerModuleName);
                var markerFeatureConfig = (0, schematics_config_mappings_1.getSchematicsConfigByFeatureOrThrow)(markerFeature);
                var markerModuleConfig = getModuleConfig(wrapperOptions.markerModuleName, markerFeatureConfig);
                if (!markerModuleConfig ||
                    markerModuleExists(options, tree, markerModuleConfig)) {
                    continue;
                }
                var targetModuleName = wrapperOptions.featureModuleName;
                var targetFeature_1 = (0, schematics_config_mappings_1.getKeyByMappingValueOrThrow)(schematics_config_mappings_1.featureFeatureModuleMapping, targetModuleName);
                var targetFeatureConfig_1 = (0, schematics_config_mappings_1.getSchematicsConfigByFeatureOrThrow)(targetFeature_1);
                var targetModuleConfig = getModuleConfig(targetModuleName, targetFeatureConfig_1);
                var message = "Attempted to append '".concat(targetModuleName, "' module ");
                message += "from '".concat(targetModuleConfig === null || targetModuleConfig === void 0 ? void 0 : targetModuleConfig.importPath, "' after the ");
                message += "'".concat(wrapperOptions.markerModuleName, "' from '").concat(markerModuleConfig.importPath, "', ");
                message += "but could not find '".concat(wrapperOptions.markerModuleName, "'.");
                message += "\n";
                message += "Please make sure the '".concat(markerFeature, "' is installed by running:\n");
                message += "> ng add @spartacus/schematics --features=".concat(markerFeature);
                throw new schematics_1.SchematicsException(message);
            }
        }
        logDebugInfo("\u2705  Application analysis complete.");
        function logDebugInfo(message) {
            if (options.debug) {
                context.logger.info(message);
            }
        }
    };
}
exports.analyzeApplication = analyzeApplication;
function markerModuleExists(options, tree, markerModuleConfig) {
    var basePath = process.cwd();
    var buildPaths = (0, project_tsconfig_paths_1.getProjectTsConfigPaths)(tree, options.project).buildPaths;
    for (var _i = 0, buildPaths_1 = buildPaths; _i < buildPaths_1.length; _i++) {
        var tsconfigPath = buildPaths_1[_i];
        var appSourceFiles = (0, program_1.createProgram)(tree, basePath, tsconfigPath).appSourceFiles;
        if (findFeatureModule(markerModuleConfig, appSourceFiles)) {
            return true;
        }
    }
    return false;
}
/**
 * Searches through feature modules,
 * and looks for either the static or
 * dynamic imports.
 */
function findFeatureModule(moduleConfig, appSourceFiles) {
    var moduleConfigs = [].concat(moduleConfig);
    for (var _i = 0, appSourceFiles_2 = appSourceFiles; _i < appSourceFiles_2.length; _i++) {
        var sourceFile = appSourceFiles_2[_i];
        for (var _a = 0, moduleConfigs_1 = moduleConfigs; _a < moduleConfigs_1.length; _a++) {
            var moduleConfig_1 = moduleConfigs_1[_a];
            if (isStaticallyImported(sourceFile, moduleConfig_1)) {
                return sourceFile;
            }
            if (isDynamicallyImported(sourceFile, moduleConfig_1)) {
                return sourceFile;
            }
        }
    }
    return undefined;
}
exports.findFeatureModule = findFeatureModule;
function isStaticallyImported(sourceFile, moduleConfig) {
    var _a, _b, _c;
    if (!(0, import_utils_1.staticImportExists)(sourceFile, moduleConfig.importPath, moduleConfig.name)) {
        false;
    }
    var elements = (_b = (_a = (0, new_module_utils_1.getModulePropertyInitializer)(sourceFile, 'imports', false)) === null || _a === void 0 ? void 0 : _a.getElements()) !== null && _b !== void 0 ? _b : [];
    for (var _i = 0, elements_1 = elements; _i < elements_1.length; _i++) {
        var element = elements_1[_i];
        var moduleName = (_c = element.getText().split('.').pop()) !== null && _c !== void 0 ? _c : '';
        if (moduleName === moduleConfig.name) {
            return true;
        }
    }
    return false;
}
function isDynamicallyImported(sourceFile, moduleConfig) {
    return !!(0, import_utils_1.findDynamicImport)(sourceFile, {
        moduleSpecifier: moduleConfig.importPath,
        namedImports: [moduleConfig.name],
    });
}
/**
 * Peeks into the given dynamic import,
 * and returns referenced local source file.
 */
function getDynamicallyImportedLocalSourceFile(dynamicImport) {
    var _a;
    var importPath = (_a = (0, import_utils_1.getDynamicImportImportPath)(dynamicImport)) !== null && _a !== void 0 ? _a : '';
    if (!(0, import_utils_1.isRelative)(importPath)) {
        return;
    }
    var wrapperModuleFileName = "".concat(importPath.split('/').pop(), ".ts");
    return dynamicImport
        .getSourceFile()
        .getProject()
        .getSourceFile(function (s) { return s.getFilePath().endsWith(wrapperModuleFileName); });
}
exports.getDynamicallyImportedLocalSourceFile = getDynamicallyImportedLocalSourceFile;
function createDependentFeaturesLog(options, features) {
    var _a;
    var selectedFeatures = (_a = options.features) !== null && _a !== void 0 ? _a : [];
    var notSelectedFeatures = features.filter(function (feature) { return !selectedFeatures.includes(feature); });
    if (!notSelectedFeatures.length) {
        return;
    }
    return "\n\u2699\uFE0F Configuring the dependent features of ".concat(selectedFeatures.join(', '), ": ").concat(notSelectedFeatures.join(', '), "\n");
}
//# sourceMappingURL=feature-utils.js.map