import { Tree } from '@angular-devkit/schematics';
import { RenamedSymbol } from '../../../shared/utils/file-utils';
export declare function migrateRenamedSymbols(tree: Tree, renamedSymbols: RenamedSymbol[]): Tree;
