import { SchematicContext, Tree } from '@angular-devkit/schematics';
import { DeprecatedNode } from '../../../shared/utils/file-utils';
export declare function removedPublicApiDeprecation(tree: Tree, context: SchematicContext, removedNodes: DeprecatedNode[]): Tree;
