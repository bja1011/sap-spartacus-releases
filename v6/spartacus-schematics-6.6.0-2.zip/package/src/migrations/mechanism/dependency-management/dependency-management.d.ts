import { Rule, SchematicContext, Tree } from '@angular-devkit/schematics';
export declare function migrateDependencies(tree: Tree, context: SchematicContext, removedDependencies: string[]): Rule;
