import { SchematicContext, Tree } from '@angular-devkit/schematics';
import { ConfigDeprecation } from '../../../shared/utils/file-utils';
export declare function migrateConfigDeprecation(tree: Tree, _context: SchematicContext, configDeprecations: ConfigDeprecation[]): Tree;
