import { Rule } from '@angular-devkit/schematics';
import { ConstructorDeprecation } from '../../../shared/utils/file-utils';
export declare const CONSTRUCTOR_DEPRECATIONS_DATA: ConstructorDeprecation[];
export declare function migrate(): Rule;
