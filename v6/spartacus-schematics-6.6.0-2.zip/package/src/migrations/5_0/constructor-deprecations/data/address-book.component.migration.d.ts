import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ADDRESS_BOOK_COMPONENT_MIGRATION: ConstructorDeprecation;
