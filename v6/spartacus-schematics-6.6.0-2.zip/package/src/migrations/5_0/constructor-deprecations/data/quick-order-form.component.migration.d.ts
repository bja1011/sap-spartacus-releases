import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const QUICK_ORDER_FORM_COMPONENT_MIGRATION: ConstructorDeprecation;
