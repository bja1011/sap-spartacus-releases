import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ADDED_TO_CART_DIALOG_EVENT_LISTENER_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
