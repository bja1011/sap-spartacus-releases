import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CLOSE_ACCOUNT_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
