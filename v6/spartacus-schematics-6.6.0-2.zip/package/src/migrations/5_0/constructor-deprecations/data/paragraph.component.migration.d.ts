import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PARAGRAPH_COMPONENT_MIGRATION: ConstructorDeprecation;
