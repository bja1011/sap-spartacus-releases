import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const FORM_ERRORS_COMPONENT_MIGRATION: ConstructorDeprecation;
