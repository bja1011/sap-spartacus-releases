import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_PRODUCT_CARD_COMPONENT_MIGRATION: ConstructorDeprecation;
