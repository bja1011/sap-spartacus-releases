import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_GROUP_MENU_COMPONENT_MIGRATION: ConstructorDeprecation;
