import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CDS_MERCHANDISING_PRODUCT_SERVICE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
