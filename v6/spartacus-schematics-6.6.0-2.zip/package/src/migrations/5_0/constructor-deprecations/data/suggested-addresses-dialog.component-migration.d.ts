import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const SUGGESTED_ADDRESS_DIALOG_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
