import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ADDED_TO_CART_DIALOG_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
