import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ADDRESS_FORM_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
