import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const LOGOUT_GUARD_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
