import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_CART_ENTRY_BUNDLE_INFO_COMPONENT_MIGRATION: ConstructorDeprecation;
