import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const JSON_LD_SCRIPT_FACTORY_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
