import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_HEADER_COMPONENT_MIGRATION: ConstructorDeprecation;
