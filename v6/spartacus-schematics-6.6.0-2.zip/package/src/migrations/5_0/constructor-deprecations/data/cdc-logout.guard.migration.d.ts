import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CDC_LOGOUT_GUARD_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
