import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CART_TOTALS_COMPONENT_MIGRATION: ConstructorDeprecation;
