import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PRODUCT_INTRO_COMPONENT_MIGRATION: ConstructorDeprecation;
