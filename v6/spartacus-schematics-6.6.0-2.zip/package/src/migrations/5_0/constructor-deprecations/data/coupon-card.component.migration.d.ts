import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const COUPON_CARD_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
