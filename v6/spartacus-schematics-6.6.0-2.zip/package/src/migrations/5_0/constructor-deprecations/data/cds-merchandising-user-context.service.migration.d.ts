import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CDS_MERCHANDISING_USER_CONTEXT_SERVICE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
