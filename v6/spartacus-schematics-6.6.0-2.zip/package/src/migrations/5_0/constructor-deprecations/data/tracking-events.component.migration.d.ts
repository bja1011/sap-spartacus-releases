import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const TRACKING_EVENTS_COMPONENT_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
