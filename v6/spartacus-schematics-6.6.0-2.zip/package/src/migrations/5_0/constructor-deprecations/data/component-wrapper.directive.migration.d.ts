import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const COMPONENT_WRAPPER_DIRECTIVE_MIGRATION: ConstructorDeprecation;
