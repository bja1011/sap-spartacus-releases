import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_TAB_BAR_COMPONENT_MIGRATION: ConstructorDeprecation;
