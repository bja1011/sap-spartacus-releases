import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const GENERIC_LINK_COMPONENT_MIGRATION: ConstructorDeprecation;
