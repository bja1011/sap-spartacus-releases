import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const LOGIN_GUARD_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
