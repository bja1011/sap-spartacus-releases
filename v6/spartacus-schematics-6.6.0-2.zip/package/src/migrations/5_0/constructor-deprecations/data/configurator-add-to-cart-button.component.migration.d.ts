import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ADD_TO_CART_BUTTON_COMPONENT_MIGRATION: ConstructorDeprecation;
