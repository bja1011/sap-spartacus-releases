import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const TAB_PARAGRAPH_CONTAINER_COMPONENT_MIGRATION: ConstructorDeprecation;
