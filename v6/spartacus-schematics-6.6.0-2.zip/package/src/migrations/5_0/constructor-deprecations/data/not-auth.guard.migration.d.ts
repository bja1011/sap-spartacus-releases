import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const NOT_AUTH_GUARD_MIGRATION: ConstructorDeprecation;
