import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const INNER_COMPONENTS_HOST_DIRECTIVE_MIGRATION: ConstructorDeprecation;
