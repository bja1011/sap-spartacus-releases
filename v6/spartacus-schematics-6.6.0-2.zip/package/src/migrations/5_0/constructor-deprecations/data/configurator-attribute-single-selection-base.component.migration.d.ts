import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_SINGLE_SELECTION_BASE_COMPONENT_MIGRATION: ConstructorDeprecation;
