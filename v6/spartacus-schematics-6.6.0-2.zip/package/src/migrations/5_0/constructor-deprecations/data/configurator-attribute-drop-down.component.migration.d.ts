import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_DROP_DOWN_COMPONENT_MIGRATION: ConstructorDeprecation;
