import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CDS_MERCHANDISING_PRODUCT_SERVICE_MIGRATION: MethodPropertyDeprecation[];
