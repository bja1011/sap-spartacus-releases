import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_SINGLE_SELECTION_BUNDLE_COMPONENT_MIGRATION: MethodPropertyDeprecation[];
