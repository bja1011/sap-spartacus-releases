import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_COMMONS_SERVICE_MIGRATION: MethodPropertyDeprecation[];
