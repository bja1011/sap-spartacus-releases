import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_GROUP_TITLE_COMPONENT_MIGRATION: MethodPropertyDeprecation[];
