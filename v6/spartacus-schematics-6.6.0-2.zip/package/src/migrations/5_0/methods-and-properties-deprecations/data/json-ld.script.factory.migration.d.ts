import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const JSON_LD_SCRIPT_FACTORY_MIGRATION: MethodPropertyDeprecation[];
