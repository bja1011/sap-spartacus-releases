import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_STOREFRONT_UTILS_SERVICE_MIGRATION: MethodPropertyDeprecation[];
