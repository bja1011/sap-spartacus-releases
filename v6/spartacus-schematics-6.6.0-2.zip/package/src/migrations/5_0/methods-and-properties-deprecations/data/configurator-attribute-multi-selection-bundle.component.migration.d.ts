import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const CONFIGURATOR_ATTRIBUTE_MULTI_SELECTION_BUNDLE_COMPONENT_MIGRATION: MethodPropertyDeprecation[];
