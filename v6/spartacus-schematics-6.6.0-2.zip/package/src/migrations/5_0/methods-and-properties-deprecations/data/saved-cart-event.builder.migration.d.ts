import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const SAVED_CART_EVENT_BUILDER_MIGRATION: MethodPropertyDeprecation[];
