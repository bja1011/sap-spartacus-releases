import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const QUICK_ORDER_SERVICE_MIGRATION: MethodPropertyDeprecation[];
