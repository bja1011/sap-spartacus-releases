import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const OCC_CONFIGURATOR_VARIANT_NORMALIZER_MIGRATION: MethodPropertyDeprecation[];
