import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const AUTH_HTTP_HEADER_SERVICE_MIGRATION: MethodPropertyDeprecation[];
