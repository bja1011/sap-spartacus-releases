import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const NAVIGATION_UI_COMPONENT_MIGRATION: MethodPropertyDeprecation[];
