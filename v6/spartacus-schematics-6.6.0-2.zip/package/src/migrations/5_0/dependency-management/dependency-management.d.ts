import { Rule } from '@angular-devkit/schematics';
export declare const REMOVED_DEPENDENCIES: string[];
export declare function migrate(): Rule;
