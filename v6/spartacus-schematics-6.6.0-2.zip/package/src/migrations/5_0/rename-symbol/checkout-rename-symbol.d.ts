import { RenamedSymbol } from '../../../shared/utils/file-utils';
export declare const CHECKOUT_RENAMED_SYMBOLS_DATA: RenamedSymbol[];
