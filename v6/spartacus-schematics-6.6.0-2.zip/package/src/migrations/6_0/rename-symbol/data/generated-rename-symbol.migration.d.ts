import { RenamedSymbol } from '../../../../shared/utils/file-utils';
export declare const GENERATED_RENAMED_SYMBOLS_DATA: RenamedSymbol[];
