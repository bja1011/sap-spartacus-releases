import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const GENERATED_CONSTRUCTOR_MIGRATIONS: ConstructorDeprecation[];
