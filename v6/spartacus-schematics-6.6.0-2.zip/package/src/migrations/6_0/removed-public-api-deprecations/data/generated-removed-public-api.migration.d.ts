import { DeprecatedNode } from '../../../../shared/utils/file-utils';
export declare const GENERATED_REMOVED_PUBLIC_API_DATA: DeprecatedNode[];
