import { MethodPropertyDeprecation } from '../../../../shared/utils/file-utils';
export declare const GENERATED_METHODS_AND_PROPERTIES_MIGRATION: MethodPropertyDeprecation[];
