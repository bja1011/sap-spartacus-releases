import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const USER_INTERESTS_SERVICE_MIGRATION: ConstructorDeprecation;
