import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const STAR_RATING_COMPONENT_MIGRATION: ConstructorDeprecation;
