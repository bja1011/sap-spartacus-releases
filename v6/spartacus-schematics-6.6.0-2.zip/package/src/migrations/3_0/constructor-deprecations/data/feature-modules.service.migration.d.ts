import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const FEATURE_MODULES_SERVICE_MIGRATION: ConstructorDeprecation;
