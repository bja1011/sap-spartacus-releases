import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PLACE_ORDER_COMPONENT_MIGRATION: ConstructorDeprecation;
