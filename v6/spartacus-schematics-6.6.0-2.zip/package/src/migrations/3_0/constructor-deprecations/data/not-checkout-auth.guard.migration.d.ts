import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const NOT_CHECKOUT_AUTH_GUARD_MIGRATION: ConstructorDeprecation;
