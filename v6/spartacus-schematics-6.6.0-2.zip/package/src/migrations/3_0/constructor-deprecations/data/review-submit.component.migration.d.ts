import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const REVIEW_SUBMIT_COMPONENT_MIGRATION: ConstructorDeprecation;
