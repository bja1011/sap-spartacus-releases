import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const AUTH_GUARD_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
