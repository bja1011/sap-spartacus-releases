import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const DELIVERY_MODE_COMPONENT_MIGRATION: ConstructorDeprecation;
