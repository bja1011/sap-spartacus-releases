import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const SPLIT_VIEW_COMPONENT_MIGRATION: ConstructorDeprecation;
