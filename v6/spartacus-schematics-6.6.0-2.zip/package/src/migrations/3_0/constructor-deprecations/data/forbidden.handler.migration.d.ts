import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const FORBIDDEN_HANDLER_MIGRATION: ConstructorDeprecation;
