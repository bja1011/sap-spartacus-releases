import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const WISH_LIST_SERVICE_MIGRATION: ConstructorDeprecation;
