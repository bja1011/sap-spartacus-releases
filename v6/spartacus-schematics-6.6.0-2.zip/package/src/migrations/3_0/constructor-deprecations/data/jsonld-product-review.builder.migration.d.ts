import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const JSONLD_PRODUCT_REVIEW_BUILDER_MIGRATION: ConstructorDeprecation;
