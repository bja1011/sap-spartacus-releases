import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PRODUCT_VARIANT_GUARD_MIGRATION: ConstructorDeprecation;
