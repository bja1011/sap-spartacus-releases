import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const USER_PAYMENT_SERVICE_MIGRATION: ConstructorDeprecation;
