import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_SERVICE_MIGRATION: ConstructorDeprecation;
