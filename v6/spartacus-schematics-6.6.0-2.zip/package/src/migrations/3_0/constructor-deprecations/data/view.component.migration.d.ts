import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const VIEW_COMPONENT_MIGRATION: ConstructorDeprecation;
