import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const USER_SERVICE_MIGRATION: ConstructorDeprecation;
