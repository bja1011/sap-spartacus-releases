import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_PROGRESS_MOBILE_BOTTOM_COMPONENT_MIGRATION: ConstructorDeprecation;
