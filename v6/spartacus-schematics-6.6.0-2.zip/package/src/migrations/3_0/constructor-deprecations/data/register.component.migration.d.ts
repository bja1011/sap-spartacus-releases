import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const REGISTER_COMPONENT_MIGRATION: ConstructorDeprecation;
