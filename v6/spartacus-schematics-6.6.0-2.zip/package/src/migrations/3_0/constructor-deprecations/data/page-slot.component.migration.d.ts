import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PAGE_SLOT_COMPONENT_MIGRATION: ConstructorDeprecation;
