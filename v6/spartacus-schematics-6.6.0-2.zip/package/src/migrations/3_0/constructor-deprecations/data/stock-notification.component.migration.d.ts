import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const STOCK_NOTIFICATION_COMPONENT_MIGRATION: ConstructorDeprecation;
