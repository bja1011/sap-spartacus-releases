import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ORDER_RETURN_REQUEST_SERVICE_MIGRATION: ConstructorDeprecation;
