import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ORDER_HISTORY_COMPONENT_MIGRATION: ConstructorDeprecation;
