import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PAYMENT_METHOD_COMPONENT_MIGRATION: ConstructorDeprecation;
