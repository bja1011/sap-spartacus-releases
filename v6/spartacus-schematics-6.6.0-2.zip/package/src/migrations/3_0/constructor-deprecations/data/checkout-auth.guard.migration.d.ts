import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_AUTH_GUARD_MIGRATION: ConstructorDeprecation;
