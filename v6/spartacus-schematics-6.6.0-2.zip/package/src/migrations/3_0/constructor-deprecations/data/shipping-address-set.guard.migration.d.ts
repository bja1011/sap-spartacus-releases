import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const SHIPPING_ADDRESS_SET_GUARD_MIGRATION: ConstructorDeprecation;
