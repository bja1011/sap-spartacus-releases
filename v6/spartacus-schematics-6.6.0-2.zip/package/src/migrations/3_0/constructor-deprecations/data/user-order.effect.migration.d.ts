import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const USER_ORDERS_EFFECT_MIGRATION: ConstructorDeprecation;
