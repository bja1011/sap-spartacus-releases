import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const ACTIVE_CART_SERVICE_MIGRATION: ConstructorDeprecation;
