import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const LOGIN_FORM_COMPONENT_MIGRATION: ConstructorDeprecation;
