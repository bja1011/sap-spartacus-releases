import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CART_VOUCHER_SERVICE_MIGRATION: ConstructorDeprecation;
