import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CUSTOMER_COUPON_SERVICE_MIGRATION: ConstructorDeprecation;
