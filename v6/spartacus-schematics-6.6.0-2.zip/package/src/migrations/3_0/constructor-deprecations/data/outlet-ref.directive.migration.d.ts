import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const OUTLET_REF_DIRECTIVE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
