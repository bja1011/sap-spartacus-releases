import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const AUTH_SERVICE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
