import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const PAYMENT_DETAILS_SET_GUARD_MIGRATION: ConstructorDeprecation;
