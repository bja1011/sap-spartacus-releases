import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CDC_AUTH_SERVICE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
