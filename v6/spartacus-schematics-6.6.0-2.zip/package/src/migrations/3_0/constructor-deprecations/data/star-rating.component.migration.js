"use strict";
/*
 * SPDX-FileCopyrightText: 2023 SAP Spartacus team <spartacus-team@sap.com>
 *
 * SPDX-License-Identifier: Apache-2.0
 */
Object.defineProperty(exports, "__esModule", { value: true });
exports.STAR_RATING_COMPONENT_MIGRATION = void 0;
var constants_1 = require("../../../../shared/constants");
var libs_constants_1 = require("../../../../shared/libs-constants");
exports.STAR_RATING_COMPONENT_MIGRATION = {
    // projects\storefrontlib\src\shared\components\star-rating\star-rating.component.ts
    class: constants_1.STAR_RATING_COMPONENT,
    importPath: libs_constants_1.SPARTACUS_STOREFRONTLIB,
    deprecatedParams: [
        {
            className: constants_1.ELEMENT_REF,
            importPath: constants_1.ANGULAR_CORE,
        },
        {
            className: constants_1.RENDERER_2,
            importPath: constants_1.ANGULAR_CORE,
        },
    ],
    removeParams: [
        {
            className: constants_1.ELEMENT_REF,
            importPath: constants_1.ANGULAR_CORE,
        },
        {
            className: constants_1.RENDERER_2,
            importPath: constants_1.ANGULAR_CORE,
        },
    ],
};
//# sourceMappingURL=star-rating.component.migration.js.map