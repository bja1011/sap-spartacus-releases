import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_GUARD_MIGRATION: ConstructorDeprecation;
