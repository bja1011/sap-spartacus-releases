import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const AUTH_REDIRECT_SERVICE_CONSTRUCTOR_MIGRATION: ConstructorDeprecation;
