import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_PROGRESS_COMPONENT_MIGRATION: ConstructorDeprecation;
