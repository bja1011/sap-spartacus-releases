import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const CART_NOT_EMPTY_GUARD_MIGRATION: ConstructorDeprecation;
