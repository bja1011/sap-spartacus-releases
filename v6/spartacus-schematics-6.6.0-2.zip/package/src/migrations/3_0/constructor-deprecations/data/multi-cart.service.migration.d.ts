import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const MULTI_CART_SERVICE_MIGRATION: ConstructorDeprecation;
