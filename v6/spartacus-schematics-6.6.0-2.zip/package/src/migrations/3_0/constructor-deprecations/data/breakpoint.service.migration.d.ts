import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const BREAKPOINT_SERVICE_MIGRATION: ConstructorDeprecation;
