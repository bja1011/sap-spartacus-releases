import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const DELIVERY_MODE_SET_GUARD_MIGRATION: ConstructorDeprecation;
