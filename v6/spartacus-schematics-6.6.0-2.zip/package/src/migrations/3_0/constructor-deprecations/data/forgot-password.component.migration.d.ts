import { ConstructorDeprecation } from '../../../../shared/utils/file-utils';
export declare const FORGOT_PASSWORD_COMPONENT_MIGRATION: ConstructorDeprecation;
