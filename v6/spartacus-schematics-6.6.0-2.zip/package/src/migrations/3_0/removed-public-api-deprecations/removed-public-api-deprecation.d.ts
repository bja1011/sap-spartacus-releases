import { Rule } from '@angular-devkit/schematics';
import { DeprecatedNode } from '../../../shared/utils/file-utils';
export declare const REMOVED_PUBLIC_API_DATA: DeprecatedNode[];
export declare function migrate(): Rule;
