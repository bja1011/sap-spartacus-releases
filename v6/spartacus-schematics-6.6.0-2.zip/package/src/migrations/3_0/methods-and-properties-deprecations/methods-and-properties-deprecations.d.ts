import { Rule } from '@angular-devkit/schematics';
import { MethodPropertyDeprecation } from '../../../shared/utils/file-utils';
export declare const METHOD_PROPERTY_DATA: MethodPropertyDeprecation[];
export declare function migrate(): Rule;
