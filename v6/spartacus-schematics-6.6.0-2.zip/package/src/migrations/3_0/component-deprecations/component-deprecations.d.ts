import { Rule } from '@angular-devkit/schematics';
import { ComponentData } from '../../../shared/utils/file-utils';
export declare const COMPONENT_DEPRECATION_DATA: ComponentData[];
export declare function migrate(): Rule;
