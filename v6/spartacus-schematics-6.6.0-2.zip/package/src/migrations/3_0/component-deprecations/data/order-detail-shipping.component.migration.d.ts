import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const ORDER_DETAIL_SHIPPING_COMPONENT_MIGRATION: ComponentData;
