import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const CART_ITEM_COMPONENT_MIGRATION: ComponentData;
