import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const SHIPPING_ADDRESS_COMPONENT_MIGRATION: ComponentData;
