import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const CLOSE_ACCOUNT_MODAL_COMPONENT_MIGRATION: ComponentData;
