import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const CHECKOUT_PROGRESS_MOBILE_TOP_COMPONENT_MIGRATION: ComponentData;
