import { ComponentData } from '../../../../shared/utils/file-utils';
export declare const ADD_TO_CART_COMPONENT_MIGRATION: ComponentData;
