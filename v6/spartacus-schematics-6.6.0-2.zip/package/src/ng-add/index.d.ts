import { Rule } from '@angular-devkit/schematics';
import { Schema as SpartacusOptions } from '../add-spartacus/schema';
export default function (options: SpartacusOptions): Rule;
