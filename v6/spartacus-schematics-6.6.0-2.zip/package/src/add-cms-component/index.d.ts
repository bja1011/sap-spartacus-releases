import { Rule } from '@angular-devkit/schematics';
import { CxCmsComponentSchema } from './schema';
export declare function addCmsComponent(options: CxCmsComponentSchema): Rule;
